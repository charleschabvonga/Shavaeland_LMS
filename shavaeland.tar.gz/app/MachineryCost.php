<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class MachineryCost
 *
 * @package App
 * @property string $road_freight_number
 * @property string $route
 * @property string $distance
 * @property enum $load_status
 * @property string $truck_attachment_status
 * @property string $machinery_attachment_type
 * @property string $size
 * @property string $vehicle_description
 * @property decimal $purchase_price
 * @property decimal $salvage_value
 * @property decimal $avg_investment
 * @property decimal $depreciation
 * @property decimal $insurance
 * @property decimal $license
 * @property decimal $fuel_price
 * @property double $fuel_usage
 * @property decimal $fuel
 * @property double $fuel_consumption
 * @property decimal $oil_price
 * @property double $oil_usage
 * @property decimal $oil
 * @property double $oil_consumption
 * @property double $number_of_tyres
 * @property decimal $tyre_price
 * @property decimal $tyre
 * @property decimal $repair_maintenance
 * @property decimal $contigency_factor
 * @property decimal $total_costs
 * @property enum $attachment_type
*/
class MachineryCost extends Model
{
    use SoftDeletes;

    protected $fillable = ['distance', 'load_status', 'purchase_price', 'salvage_value', 'avg_investment', 'depreciation', 'insurance', 'license', 'fuel_price', 'fuel_usage', 'fuel', 'fuel_consumption', 'oil_price', 'oil_usage', 'oil', 'oil_consumption', 'number_of_tyres', 'tyre_price', 'tyre', 'repair_maintenance', 'contigency_factor', 'total_costs', 'attachment_type', 'road_freight_number_id', 'route_id', 'truck_attachment_status_id', 'machinery_attachment_type_id', 'size_id', 'vehicle_description_id'];
    protected $hidden = [];
    
    
    public static function boot()
    {
        parent::boot();

        MachineryCost::observe(new \App\Observers\UserActionsObserver);
    }

    public static $enum_load_status = ["Empty" => "Empty", "Loaded" => "Loaded"];

    public static $enum_attachment_type = ["Tri axle" => "Tri axle", "Link" => "Link", "Rigid" => "Rigid"];

    /**
     * Set to null if empty
     * @param $input
     */
    public function setRoadFreightNumberIdAttribute($input)
    {
        $this->attributes['road_freight_number_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setRouteIdAttribute($input)
    {
        $this->attributes['route_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setTruckAttachmentStatusIdAttribute($input)
    {
        $this->attributes['truck_attachment_status_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setMachineryAttachmentTypeIdAttribute($input)
    {
        $this->attributes['machinery_attachment_type_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setSizeIdAttribute($input)
    {
        $this->attributes['size_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setVehicleDescriptionIdAttribute($input)
    {
        $this->attributes['vehicle_description_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setPurchasePriceAttribute($input)
    {
        $this->attributes['purchase_price'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setSalvageValueAttribute($input)
    {
        $this->attributes['salvage_value'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setAvgInvestmentAttribute($input)
    {
        $this->attributes['avg_investment'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setDepreciationAttribute($input)
    {
        $this->attributes['depreciation'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setInsuranceAttribute($input)
    {
        $this->attributes['insurance'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setLicenseAttribute($input)
    {
        $this->attributes['license'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setFuelPriceAttribute($input)
    {
        $this->attributes['fuel_price'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setFuelUsageAttribute($input)
    {
        if ($input != '') {
            $this->attributes['fuel_usage'] = $input;
        } else {
            $this->attributes['fuel_usage'] = null;
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setFuelAttribute($input)
    {
        $this->attributes['fuel'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setFuelConsumptionAttribute($input)
    {
        if ($input != '') {
            $this->attributes['fuel_consumption'] = $input;
        } else {
            $this->attributes['fuel_consumption'] = null;
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setOilPriceAttribute($input)
    {
        $this->attributes['oil_price'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setOilUsageAttribute($input)
    {
        if ($input != '') {
            $this->attributes['oil_usage'] = $input;
        } else {
            $this->attributes['oil_usage'] = null;
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setOilAttribute($input)
    {
        $this->attributes['oil'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setOilConsumptionAttribute($input)
    {
        if ($input != '') {
            $this->attributes['oil_consumption'] = $input;
        } else {
            $this->attributes['oil_consumption'] = null;
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setNumberOfTyresAttribute($input)
    {
        if ($input != '') {
            $this->attributes['number_of_tyres'] = $input;
        } else {
            $this->attributes['number_of_tyres'] = null;
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setTyrePriceAttribute($input)
    {
        $this->attributes['tyre_price'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setTyreAttribute($input)
    {
        $this->attributes['tyre'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setRepairMaintenanceAttribute($input)
    {
        $this->attributes['repair_maintenance'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setContigencyFactorAttribute($input)
    {
        $this->attributes['contigency_factor'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setTotalCostsAttribute($input)
    {
        $this->attributes['total_costs'] = $input ? $input : null;
    }
    
    public function road_freight_number()
    {
        return $this->belongsTo(RoadFreight::class, 'road_freight_number_id')->withTrashed();
    }
    
    public function route()
    {
        return $this->belongsTo(Route::class, 'route_id')->withTrashed();
    }
    
    public function truck_attachment_status()
    {
        return $this->belongsTo(TruckAttachmentStatus::class, 'truck_attachment_status_id')->withTrashed();
    }
    
    public function machinery_attachment_type()
    {
        return $this->belongsTo(MachineryType::class, 'machinery_attachment_type_id')->withTrashed();
    }
    
    public function size()
    {
        return $this->belongsTo(MachinerySize::class, 'size_id')->withTrashed();
    }
    
    public function vehicle_description()
    {
        return $this->belongsTo(Vehicle::class, 'vehicle_description_id')->withTrashed();
    }
    
}
