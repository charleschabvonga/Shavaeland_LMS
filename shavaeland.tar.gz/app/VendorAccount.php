<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class VendorAccount
 *
 * @package App
 * @property string $vendor
 * @property string $contact_person
 * @property string $account_manager
 * @property string $account_number
 * @property enum $status
*/
class VendorAccount extends Model
{
    use SoftDeletes;

    protected $fillable = ['account_number', 'status', 'vendor_id', 'contact_person_id', 'account_manager_id'];
    protected $hidden = [];
    
    
    public static function boot()
    {
        parent::boot();

        VendorAccount::observe(new \App\Observers\UserActionsObserver);
    }

    public static $enum_status = ["Not active" => "Not active", "Payment due" => "Payment due", "Up to date" => "Up to date", "Paid off" => "Paid off", "Credit available" => "Credit available", "Refund pymt due" => "Refund pymt due", "Closed" => "Closed"];

    /**
     * Set to null if empty
     * @param $input
     */
    public function setVendorIdAttribute($input)
    {
        $this->attributes['vendor_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setContactPersonIdAttribute($input)
    {
        $this->attributes['contact_person_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setAccountManagerIdAttribute($input)
    {
        $this->attributes['account_manager_id'] = $input ? $input : null;
    }
    
    public function vendor()
    {
        return $this->belongsTo(Vendor::class, 'vendor_id')->withTrashed();
    }
    
    public function contact_person()
    {
        return $this->belongsTo(VendorContact::class, 'contact_person_id')->withTrashed();
    }
    
    public function account_manager()
    {
        return $this->belongsTo(Employee::class, 'account_manager_id')->withTrashed();
    }
    
}
