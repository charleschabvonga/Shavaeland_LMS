<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class ClientAccount
 *
 * @package App
 * @property string $client
 * @property string $contact_person
 * @property string $account_manager
 * @property string $account_number
 * @property enum $status
*/
class ClientAccount extends Model
{
    use SoftDeletes;

    protected $fillable = ['account_number', 'status', 'client_id', 'contact_person_id', 'account_manager_id'];
    protected $hidden = [];
    
    
    public static function boot()
    {
        parent::boot();

        ClientAccount::observe(new \App\Observers\UserActionsObserver);
    }

    public static $enum_status = ["Not active" => "Not active", "Payment due" => "Payment due", "Up to date" => "Up to date", "Paid off" => "Paid off", "Credit available" => "Credit available", "Refund pymt due" => "Refund pymt due", "Closed" => "Closed"];

    /**
     * Set to null if empty
     * @param $input
     */
    public function setClientIdAttribute($input)
    {
        $this->attributes['client_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setContactPersonIdAttribute($input)
    {
        $this->attributes['contact_person_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setAccountManagerIdAttribute($input)
    {
        $this->attributes['account_manager_id'] = $input ? $input : null;
    }
    
    public function client()
    {
        return $this->belongsTo(TimeProject::class, 'client_id');
    }
    
    public function contact_person()
    {
        return $this->belongsTo(ClientContact::class, 'contact_person_id')->withTrashed();
    }
    
    public function account_manager()
    {
        return $this->belongsTo(Employee::class, 'account_manager_id')->withTrashed();
    }
    
}
