<?php

namespace App\Http\Controllers\Admin;

use App\EmployeeDesignation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreEmployeeDesignationsRequest;
use App\Http\Requests\Admin\UpdateEmployeeDesignationsRequest;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class EmployeeDesignationsController extends Controller
{
    /**
     * Display a listing of EmployeeDesignation.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (! Gate::allows('employee_designation_access')) {
            return abort(401);
        }


        if (request('show_deleted') == 1) {
            if (! Gate::allows('employee_designation_delete')) {
                return abort(401);
            }
            $employee_designations = EmployeeDesignation::onlyTrashed()->get();
        } else {
            $employee_designations = EmployeeDesignation::all();
        }

        return view('admin.employee_designations.index', compact('employee_designations'));
    }

    /**
     * Show the form for creating new EmployeeDesignation.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (! Gate::allows('employee_designation_create')) {
            return abort(401);
        }
        return view('admin.employee_designations.create');
    }

    /**
     * Store a newly created EmployeeDesignation in storage.
     *
     * @param  \App\Http\Requests\StoreEmployeeDesignationsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreEmployeeDesignationsRequest $request)
    {
        if (! Gate::allows('employee_designation_create')) {
            return abort(401);
        }
        $employee_designation = EmployeeDesignation::create($request->all());



        return redirect()->route('admin.employee_designations.index');
    }


    /**
     * Show the form for editing EmployeeDesignation.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (! Gate::allows('employee_designation_edit')) {
            return abort(401);
        }
        $employee_designation = EmployeeDesignation::findOrFail($id);

        return view('admin.employee_designations.edit', compact('employee_designation'));
    }

    /**
     * Update EmployeeDesignation in storage.
     *
     * @param  \App\Http\Requests\UpdateEmployeeDesignationsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateEmployeeDesignationsRequest $request, $id)
    {
        if (! Gate::allows('employee_designation_edit')) {
            return abort(401);
        }
        $employee_designation = EmployeeDesignation::findOrFail($id);
        $employee_designation->update($request->all());



        return redirect()->route('admin.employee_designations.index');
    }


    /**
     * Display EmployeeDesignation.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (! Gate::allows('employee_designation_view')) {
            return abort(401);
        }
        $employees = \App\Employee::where('designation_id', $id)->get();

        $employee_designation = EmployeeDesignation::findOrFail($id);

        return view('admin.employee_designations.show', compact('employee_designation', 'employees'));
    }


    /**
     * Remove EmployeeDesignation from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (! Gate::allows('employee_designation_delete')) {
            return abort(401);
        }
        $employee_designation = EmployeeDesignation::findOrFail($id);
        $employee_designation->delete();

        return redirect()->route('admin.employee_designations.index');
    }

    /**
     * Delete all selected EmployeeDesignation at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if (! Gate::allows('employee_designation_delete')) {
            return abort(401);
        }
        if ($request->input('ids')) {
            $entries = EmployeeDesignation::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore EmployeeDesignation from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        if (! Gate::allows('employee_designation_delete')) {
            return abort(401);
        }
        $employee_designation = EmployeeDesignation::onlyTrashed()->findOrFail($id);
        $employee_designation->restore();

        return redirect()->route('admin.employee_designations.index');
    }

    /**
     * Permanently delete EmployeeDesignation from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        if (! Gate::allows('employee_designation_delete')) {
            return abort(401);
        }
        $employee_designation = EmployeeDesignation::onlyTrashed()->findOrFail($id);
        $employee_designation->forceDelete();

        return redirect()->route('admin.employee_designations.index');
    }
}
