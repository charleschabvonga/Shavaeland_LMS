<?php

namespace App\Http\Controllers\Admin;

use App\DebitNote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreDebitNotesRequest;
use App\Http\Requests\Admin\UpdateDebitNotesRequest;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class DebitNotesController extends Controller
{
    /**
     * Display a listing of DebitNote.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (! Gate::allows('debit_note_access')) {
            return abort(401);
        }


                $debit_notes = DebitNote::all();

        return view('admin.debit_notes.index', compact('debit_notes'));
    }

    /**
     * Show the form for creating new DebitNote.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (! Gate::allows('debit_note_create')) {
            return abort(401);
        }
        
        $credit_note_payment_numbers = \App\Expense::get()->pluck('payment_number', 'id')->prepend(trans('global.app_please_select'), '');
        $transaction_numbers = \App\TimeEntry::get()->pluck('operation_number', 'id')->prepend(trans('global.app_please_select'), '');
        $credit_note_numbers = \App\ExpenseCategory::get()->pluck('credit_note_number', 'id')->prepend(trans('global.app_please_select'), '');
        $withdrawal_transaction_numbers = \App\VendorBankPayment::get()->pluck('payment_number', 'id')->prepend(trans('global.app_please_select'), '');
        $vendors = \App\Vendor::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $contact_people = \App\VendorContact::get()->pluck('contact_name', 'id')->prepend(trans('global.app_please_select'), '');
        $account_managers = \App\Employee::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $currencies = \App\Currency::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $enum_refund_type = DebitNote::$enum_refund_type;
                    $enum_status = DebitNote::$enum_status;
            
        return view('admin.debit_notes.create', compact('enum_refund_type', 'enum_status', 'credit_note_payment_numbers', 'transaction_numbers', 'credit_note_numbers', 'withdrawal_transaction_numbers', 'vendors', 'contact_people', 'account_managers', 'currencies'));
    }

    /**
     * Store a newly created DebitNote in storage.
     *
     * @param  \App\Http\Requests\StoreDebitNotesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreDebitNotesRequest $request)
    {
        if (! Gate::allows('debit_note_create')) {
            return abort(401);
        }
        $debit_note = DebitNote::create($request->all());

        foreach ($request->input('invoice_items', []) as $data) {
            $debit_note->invoice_items()->create($data);
        }


        return redirect()->route('admin.debit_notes.index');
    }


    /**
     * Show the form for editing DebitNote.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (! Gate::allows('debit_note_edit')) {
            return abort(401);
        }
        
        $credit_note_payment_numbers = \App\Expense::get()->pluck('payment_number', 'id')->prepend(trans('global.app_please_select'), '');
        $transaction_numbers = \App\TimeEntry::get()->pluck('operation_number', 'id')->prepend(trans('global.app_please_select'), '');
        $credit_note_numbers = \App\ExpenseCategory::get()->pluck('credit_note_number', 'id')->prepend(trans('global.app_please_select'), '');
        $withdrawal_transaction_numbers = \App\VendorBankPayment::get()->pluck('payment_number', 'id')->prepend(trans('global.app_please_select'), '');
        $vendors = \App\Vendor::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $contact_people = \App\VendorContact::get()->pluck('contact_name', 'id')->prepend(trans('global.app_please_select'), '');
        $account_managers = \App\Employee::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $currencies = \App\Currency::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $enum_refund_type = DebitNote::$enum_refund_type;
                    $enum_status = DebitNote::$enum_status;
            
        $debit_note = DebitNote::findOrFail($id);

        return view('admin.debit_notes.edit', compact('debit_note', 'enum_refund_type', 'enum_status', 'credit_note_payment_numbers', 'transaction_numbers', 'credit_note_numbers', 'withdrawal_transaction_numbers', 'vendors', 'contact_people', 'account_managers', 'currencies'));
    }

    /**
     * Update DebitNote in storage.
     *
     * @param  \App\Http\Requests\UpdateDebitNotesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateDebitNotesRequest $request, $id)
    {
        if (! Gate::allows('debit_note_edit')) {
            return abort(401);
        }
        $debit_note = DebitNote::findOrFail($id);
        $debit_note->update($request->all());

        $invoiceItems           = $debit_note->invoice_items;
        $currentInvoiceItemData = [];
        foreach ($request->input('invoice_items', []) as $index => $data) {
            if (is_integer($index)) {
                $debit_note->invoice_items()->create($data);
            } else {
                $id                          = explode('-', $index)[1];
                $currentInvoiceItemData[$id] = $data;
            }
        }
        foreach ($invoiceItems as $item) {
            if (isset($currentInvoiceItemData[$item->id])) {
                $item->update($currentInvoiceItemData[$item->id]);
            } else {
                $item->delete();
            }
        }


        return redirect()->route('admin.debit_notes.index');
    }


    /**
     * Display DebitNote.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (! Gate::allows('debit_note_view')) {
            return abort(401);
        }
        
        $credit_note_payment_numbers = \App\Expense::get()->pluck('payment_number', 'id')->prepend(trans('global.app_please_select'), '');
        $transaction_numbers = \App\TimeEntry::get()->pluck('operation_number', 'id')->prepend(trans('global.app_please_select'), '');
        $credit_note_numbers = \App\ExpenseCategory::get()->pluck('credit_note_number', 'id')->prepend(trans('global.app_please_select'), '');
        $withdrawal_transaction_numbers = \App\VendorBankPayment::get()->pluck('payment_number', 'id')->prepend(trans('global.app_please_select'), '');
        $vendors = \App\Vendor::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $contact_people = \App\VendorContact::get()->pluck('contact_name', 'id')->prepend(trans('global.app_please_select'), '');
        $account_managers = \App\Employee::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $currencies = \App\Currency::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$invoice_items = \App\InvoiceItem::where('debit_note_number_id', $id)->get();$expenses = \App\Expense::where('debit_note_number_id', $id)->get();$incomes = \App\Income::where('debit_note_number_id', $id)->get();$bank_payments = \App\BankPayment::where('debit_note_number_id', $id)->get();

        $debit_note = DebitNote::findOrFail($id);

        return view('admin.debit_notes.show', compact('debit_note', 'invoice_items', 'expenses', 'incomes', 'bank_payments'));
    }


    /**
     * Remove DebitNote from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (! Gate::allows('debit_note_delete')) {
            return abort(401);
        }
        $debit_note = DebitNote::findOrFail($id);
        $debit_note->delete();

        return redirect()->route('admin.debit_notes.index');
    }

    /**
     * Delete all selected DebitNote at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if (! Gate::allows('debit_note_delete')) {
            return abort(401);
        }
        if ($request->input('ids')) {
            $entries = DebitNote::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }

}
