<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class PartsAcquired
 *
 * @package App
 * @property string $order_number
 * @property string $prepared_by
 * @property string $date
 * @property enum $transaction_type
 * @property string $repair_center
 * @property string $received_by
 * @property string $dispatched_by
 * @property string $part
 * @property double $qty
 * @property decimal $unit_price
 * @property decimal $total
*/
class PartsAcquired extends Model
{
    use SoftDeletes;

    protected $fillable = ['order_number', 'prepared_by', 'date', 'transaction_type', 'qty', 'unit_price', 'total', 'repair_center_id', 'received_by_id', 'dispatched_by_id', 'part_id'];
    protected $hidden = [];
    
    
    public static function boot()
    {
        parent::boot();

        PartsAcquired::observe(new \App\Observers\UserActionsObserver);
    }

    public static $enum_transaction_type = ["Procurement" => "Procurement", "Request" => "Request"];

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDateAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['date'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['date'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDateAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setRepairCenterIdAttribute($input)
    {
        $this->attributes['repair_center_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setReceivedByIdAttribute($input)
    {
        $this->attributes['received_by_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setDispatchedByIdAttribute($input)
    {
        $this->attributes['dispatched_by_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setPartIdAttribute($input)
    {
        $this->attributes['part_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setQtyAttribute($input)
    {
        if ($input != '') {
            $this->attributes['qty'] = $input;
        } else {
            $this->attributes['qty'] = null;
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setUnitPriceAttribute($input)
    {
        $this->attributes['unit_price'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setTotalAttribute($input)
    {
        $this->attributes['total'] = $input ? $input : null;
    }
    
    public function repair_center()
    {
        return $this->belongsTo(Workshop::class, 'repair_center_id')->withTrashed();
    }
    
    public function received_by()
    {
        return $this->belongsTo(Employee::class, 'received_by_id')->withTrashed();
    }
    
    public function dispatched_by()
    {
        return $this->belongsTo(Employee::class, 'dispatched_by_id')->withTrashed();
    }
    
    public function part()
    {
        return $this->belongsTo(Part::class, 'part_id')->withTrashed();
    }
    
}
