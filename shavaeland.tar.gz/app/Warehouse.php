<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Warehouse
 *
 * @package App
 * @property string $vendor
 * @property string $center_name
 * @property double $square_meters
 * @property double $available_space
*/
class Warehouse extends Model
{
    use SoftDeletes;

    protected $fillable = ['center_name', 'square_meters', 'available_space', 'vendor_id'];
    protected $hidden = [];
    
    
    public static function boot()
    {
        parent::boot();

        Warehouse::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setVendorIdAttribute($input)
    {
        $this->attributes['vendor_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setSquareMetersAttribute($input)
    {
        if ($input != '') {
            $this->attributes['square_meters'] = $input;
        } else {
            $this->attributes['square_meters'] = null;
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setAvailableSpaceAttribute($input)
    {
        if ($input != '') {
            $this->attributes['available_space'] = $input;
        } else {
            $this->attributes['available_space'] = null;
        }
    }
    
    public function vendor()
    {
        return $this->belongsTo(Vendor::class, 'vendor_id')->withTrashed();
    }
    
}
